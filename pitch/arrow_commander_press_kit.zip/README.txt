ARROW COMMANDER - press kit
Breyer White (solo developer) - breyer@whoisbreyer.com - Instagram @whoisbreyer

Play free in your browser (all 10 stages): https://whoisbreyer.github.io/castle-warfare-demo/
Landing page: https://whoisbreyer.github.io/castle-warfare-demo/pitch/

Pitch: A 2D pixel-art castle siege. You aim every arrow yourself from the castle wall while your army fights on its own. 10 stages, five special arrows, power-up bubbles, bat swarms, siege ballistas, and a giant Black King boss. Built solo in Godot. Plays on phone and desktop today. Roadmap: 50 stages, skins and factions, new mechanics, monetization plan.

Files: gameplay GIF, key art, logo, 8 in-game screenshots (current build), one-sheet PDF.
Backdrops, key art and logo are AI-assisted. Screenshots are real gameplay from the current build.
